#!/usr/bin/env bash

scripts/create_readme_rst.sh
python setup.py build_sphinx