#!/usr/bin/env bash

pandoc --from=markdown --to=rst --output=docs/source/README.rst README.md