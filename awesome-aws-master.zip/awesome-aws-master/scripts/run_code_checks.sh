#!/usr/bin/env bash

flake8 --max-line-length=80 --exclude=build,scratch,docs .
